package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.SeatLayout;

@Repository
public interface SeatLayoutRepository  extends JpaRepository<SeatLayout, Long>{

}
