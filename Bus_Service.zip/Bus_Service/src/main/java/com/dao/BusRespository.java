package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Bus;

@Repository
public interface BusRespository extends JpaRepository<Bus, Long> {

}
