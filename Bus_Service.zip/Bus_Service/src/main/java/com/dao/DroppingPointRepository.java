package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.DroppingPoint;

@Repository
public interface DroppingPointRepository extends JpaRepository<DroppingPoint, Long>{

}
