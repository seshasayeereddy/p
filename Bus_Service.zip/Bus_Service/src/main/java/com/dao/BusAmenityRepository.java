package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.BusAmenity;

@Repository
public interface BusAmenityRepository extends JpaRepository<BusAmenity,Long>{

}
