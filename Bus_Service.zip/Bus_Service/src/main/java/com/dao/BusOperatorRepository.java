package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.BusOperator;

@Repository
public interface BusOperatorRepository extends JpaRepository<BusOperator, Long>{

}
