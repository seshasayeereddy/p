package com.handler;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dto.amenity.AmenityResponseDto;
import com.dto.amenity.CreateAmenityRequestDto;
import com.service.AmenityService;

@RestController
@RequestMapping("/amenity")
public class AmenityController {

	
	private final AmenityService amenityService;
	
	public AmenityController(AmenityService amenityService) {
		this.amenityService = amenityService;
	}
	
	
	
	@PostMapping("/createAmenity")
	public AmenityResponseDto createAmenity(@RequestBody CreateAmenityRequestDto request) {
		return amenityService.createAmenity(request);
	}
}
