package com.service;

public interface BusAmenityService {

}
