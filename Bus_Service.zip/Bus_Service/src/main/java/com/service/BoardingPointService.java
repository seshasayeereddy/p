package com.service;

public interface BoardingPointService {

}
