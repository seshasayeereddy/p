package com.service;

public interface BusService {

}
