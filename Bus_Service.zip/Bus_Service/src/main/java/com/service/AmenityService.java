package com.service;

import com.dto.amenity.AmenityResponseDto;
import com.dto.amenity.CreateAmenityRequestDto;

public interface AmenityService {

	 AmenityResponseDto createAmenity(CreateAmenityRequestDto request);
	
	
}
