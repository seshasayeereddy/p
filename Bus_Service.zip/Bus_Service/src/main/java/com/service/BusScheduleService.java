package com.service;

public interface BusScheduleService {

}
