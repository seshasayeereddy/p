package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.BoardingPointService;

@Service
public class BoardingPointServiceImpl implements BoardingPointService{

}
