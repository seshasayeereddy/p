package com.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.dao.AmenityRepository;
import com.dto.amenity.AmenityResponseDto;
import com.dto.amenity.CreateAmenityRequestDto;
import com.model.Amenity;
import com.service.AmenityService;

@Service
public class AmenityServiceImpl implements AmenityService {

	private final AmenityRepository amenityRepository;

	public AmenityServiceImpl(AmenityRepository amenityRepository) {
		this.amenityRepository = amenityRepository;
	}

	@Override
	public AmenityResponseDto createAmenity(CreateAmenityRequestDto request) {

		Amenity amenity = new Amenity();
		BeanUtils.copyProperties(request, amenity);
           
		Amenity save = amenityRepository.save(amenity);

		AmenityResponseDto amenityResponseDto = new AmenityResponseDto();

		BeanUtils.copyProperties(save, amenityResponseDto);

		return amenityResponseDto;
	}

}
