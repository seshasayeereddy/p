package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.DroppingPointService;

@Service
public class DroppingPointServiceImpl implements DroppingPointService{

}
