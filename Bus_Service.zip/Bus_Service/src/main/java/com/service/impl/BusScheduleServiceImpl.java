package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.BusScheduleService;

@Service
public class BusScheduleServiceImpl  implements BusScheduleService{

}
