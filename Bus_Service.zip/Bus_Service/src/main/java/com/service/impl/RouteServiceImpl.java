package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.RouteService;

@Service
public class RouteServiceImpl  implements RouteService{

}
