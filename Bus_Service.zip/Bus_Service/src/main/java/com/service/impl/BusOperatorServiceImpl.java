package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.BusOperatorService;

@Service
public class BusOperatorServiceImpl implements BusOperatorService{

}
