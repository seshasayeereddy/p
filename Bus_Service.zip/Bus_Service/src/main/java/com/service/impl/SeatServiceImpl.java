package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.SeatService;

@Service
public class SeatServiceImpl implements SeatService{

}
