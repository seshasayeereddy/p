package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.BusService;

@Service
public class BusServiceImpl  implements BusService{

}
