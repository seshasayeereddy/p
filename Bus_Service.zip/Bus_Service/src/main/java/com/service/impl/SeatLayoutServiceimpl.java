package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.SeatLayoutService;

@Service
public class SeatLayoutServiceimpl  implements SeatLayoutService{

}
