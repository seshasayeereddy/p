package com.service.impl;

import org.springframework.stereotype.Service;

import com.service.BusAmenityService;

@Service
public class BusAmenityServiceImpl implements BusAmenityService{

}
