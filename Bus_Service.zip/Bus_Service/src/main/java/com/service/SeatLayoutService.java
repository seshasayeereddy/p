package com.service;

public interface SeatLayoutService {

}
