package com.dto.busoperator;

public class CreateBusOperatorRequestDto {

}
