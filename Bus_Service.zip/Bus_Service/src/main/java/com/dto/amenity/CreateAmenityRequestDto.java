package com.dto.amenity;



import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateAmenityRequestDto {

	@NotBlank(message = "Amenity name is required")
	private String amenityName;
}