package com.dto.amenity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AmenityDropdownResponseDto {

    private Long id;

    private String amenityName;
}