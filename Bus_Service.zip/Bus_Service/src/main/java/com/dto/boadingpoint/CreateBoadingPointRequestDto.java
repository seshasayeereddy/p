package com.dto.boadingpoint;

public class CreateBoadingPointRequestDto {

}
