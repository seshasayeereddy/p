package com.dto.city;

public class CreateCityResponseDto {

}
