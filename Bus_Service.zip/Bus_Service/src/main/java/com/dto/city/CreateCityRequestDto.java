package com.dto.city;

public class CreateCityRequestDto {

}
